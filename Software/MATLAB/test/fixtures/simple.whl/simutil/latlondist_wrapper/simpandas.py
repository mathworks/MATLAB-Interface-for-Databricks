# simpandas.py
# Wrapper for easily simulate from Python.

import numpy as np
import pandas as pd
import os
from ctypes import cdll, c_void_p, c_double

def is_zip_file():
    return '.zip' in __file__

def base_dir():
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

def get_dll_name():
    if is_zip_file():
        return '/Volumes/main/default/myvolume/Scratch/DLLs/latlondist.so'
    else:
        return os.path.join(base_dir(), 'latlondist.so')

def get_latlondist_output_schema():
    """ A helper function to return the output schema for this model"""
    return 'Distance double'


def run_sim(pdf_in: pd.DataFrame):
    """ run_sim
    This function will run a Simulink simulation with inputs from
    the Pandas DataFrame argument """
    # First prepare outputs
    numRows = pdf_in.shape[0]
    col_Distance = np.asarray(range(numRows), 'float64')
    hDLL = cdll.LoadLibrary(get_dll_name())
    init_fun = hDLL.latlondist_initialize
    term_fun = hDLL.latlondist_terminate
    step_fun = hDLL.latlondist_step
    instantiate_fun = hDLL.latlondist_wrapper_instantiate
    instantiate_fun.restype = c_void_p
    release_fun = hDLL.latlondist_wrapper_releaseInstance

    # Setter functions
    set_mlat = hDLL.latlondist_wrapper_set_mlat
    set_mlon = hDLL.latlondist_wrapper_set_mlon
    set_plat = hDLL.latlondist_wrapper_set_plat
    set_plon = hDLL.latlondist_wrapper_set_plon
    
    # Getter functions
    get_Distance = hDLL.latlondist_wrapper_get_Distance
    get_Distance.restype = c_double
    
    # Keep local variables for sim
    vecmlat = pdf_in['mlat'].tolist()
    vecmlon = pdf_in['mlon'].tolist()
    vecplat = pdf_in['plat'].tolist()
    vecplon = pdf_in['plon'].tolist()
    
    # Get a data instance and initialize model
    mdlPtr = instantiate_fun()
    init_fun(c_void_p(mdlPtr))

    # Run simulation
    for r in range(numRows):
        # Set the inputs
        set_mlat(c_void_p(mdlPtr), c_double(vecmlat[r]))
        set_mlon(c_void_p(mdlPtr), c_double(vecmlon[r]))
        set_plat(c_void_p(mdlPtr), c_double(vecplat[r]))
        set_plon(c_void_p(mdlPtr), c_double(vecplon[r]))
        
        # Run one step
        step_fun(c_void_p(mdlPtr))

        # Retrieve the outputs
        col_Distance[r] = get_Distance(c_void_p(mdlPtr))
        
    # Release simulation resources
    term_fun(c_void_p(mdlPtr))
    release_fun(c_void_p(mdlPtr))

    # Create dataframe for output
    pdf_out = pd.DataFrame(data={'Distance': col_Distance})
    return pdf_out
    


def run_sim_iter(iterator):
    """ A function to be used with mapInPandas.
    It takes an argument an iterator over Pandas DataFrames"""
    for pdf in iterator:
        yield run_sim(pdf)


# End of file: simpandas.py 

